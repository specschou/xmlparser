package com.jrj.yqcm;

import java.io.File;
import java.io.FileReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Timer;

import com.jrj.yqcm.task.CommonTask;
import com.jrj.yqcm.task.PlayerTrainTask;
import com.jrj.yqcm.utils.Constants;
import com.jrj.yqcm.utils.PropUtil;

public class Main {
	public static void main(String[] args) throws Exception {
		String file = Constants.DIR + "list.property";
		Properties listProps = PropUtil.getProperties(file);
		System.out.println(listProps);
		int i = 0;
		for (Object o : listProps.keySet()) {
			try {
				Map<String, String> params = new HashMap<String, String>();
				Map<String, String> timeParams = new HashMap<String, String>();
				String key = o.toString();
				String itemFile = key + ".property";
				PropUtil.createFile(itemFile);
				Properties itemProps = PropUtil.getProperties(Constants.DIR
						+ itemFile);
				// System.out.println(itemProps);
				String name = itemProps.getProperty("name");
				String cookie = itemProps.getProperty("cookie");
				String loginUrl = itemProps.getProperty("loginUrl");
				String host = itemProps.getProperty("host");
				String playerId = itemProps.getProperty("playerId");
				String taskType = itemProps.getProperty("taskType");
				String leftRefreshTime = itemProps
						.getProperty("leftRefreshTime");
				String ticket = itemProps.getProperty("ticket");
				String activeBag = itemProps.getProperty("activeBag");
				String stadium = itemProps.getProperty("stadium");
				String trainIds = itemProps.getProperty("trainIds");
				Integer trainCount = 30;
				try {
					trainCount = Integer.parseInt(itemProps
							.getProperty("trainCount"));
				} catch (Exception e) {

				}
				if (ticket != null) {
					params.put("ticket", ticket);
				}
				if (activeBag != null) {
					params.put("activeBag", activeBag);
				}
				if (stadium != null) {
					timeParams.put("stadium", stadium);
				}
				if (trainIds != null) {
					timeParams.put("trainIds", trainIds);
				}
				Timer timer = new Timer();
				if (playerId != null) {
					timer.schedule(new PlayerTrainTask(name, playerId, cookie,
							loginUrl, host, trainCount), 0, 1 * 60 * 1000 + 1
							* 1000);
				}
				if (taskType != null) {
					TaskQueue tq = new TaskQueue(host, cookie, name);
					int lrt = 10 * 60;
					try {
						// lrt = Integer.parseInt(leftRefreshTime);
					} catch (Exception e) {
						e.printStackTrace();
					}
					TaskOpThread toThread = new TaskOpThread(name, tq, cookie,
							loginUrl, host, taskType, lrt);
					toThread.start();
				}
				if (params.size() > 0) {
					timer.schedule(new CommonTask(name, playerId, cookie,
							loginUrl, host, params), 0, 5 * 60 * 1000);
				}
				if (timeParams.size() > 0) {
					TimeThread timeThread = new TimeThread(name, cookie,
							loginUrl, host, timeParams);
					timeThread.start();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			i++;
		}
	}
}
