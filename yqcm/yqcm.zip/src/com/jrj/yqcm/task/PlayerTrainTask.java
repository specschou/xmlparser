package com.jrj.yqcm.task;

import java.util.Date;
import java.util.TimerTask;

import com.jrj.yqcm.utils.HttpComponentUtils;
import com.jrj.yqcm.utils.UrlConstants;

public class PlayerTrainTask extends TimerTask {
	private String name;
	private String playerId;
	private String mainCookie;
	private String loginUrl;
	private String host;
	private Integer count = 0;
	private Integer trainCount;

	public PlayerTrainTask(String name, String playerId, String mainCookie,
			String loginUrl, String host, Integer trainCount) {
		this.name = name;
		this.playerId = playerId;
		this.mainCookie = mainCookie;
		this.loginUrl = loginUrl;
		this.host = host;
		this.trainCount = trainCount;
	}

	public void run() {
		if (count < trainCount) {
			HttpComponentUtils.login(loginUrl);
			String url = (host + UrlConstants.MARKET_TRANINER).replace("$1",
					"6").replace("$2", playerId);
			// System.out.println(url);
			String content = HttpComponentUtils.get(url, mainCookie);
			if (content.indexOf("��ȴʱ��") == -1) {
				count++;
			}
			System.out.println(name + "," + ",PlayerTrainTask," + new Date()
					+ formatContent(content));
		}
	}

	public String formatContent(String content) {
		int index = -1;
		int begin = -1;
		int end = -1;
		if ((index = content.indexOf("padding-bottom:5px")) != -1) {
			begin = index + 21;
		} else if ((index = content.indexOf("public_d_content")) != -1) {
			begin = index + 18;
		}
		end = content.indexOf("</div>", index);
		if (begin != -1 && end != -1) {
			content = content.substring(begin, end);
		}
		return content;
	}
}
