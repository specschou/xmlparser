package com.jrj.yqcm;

import java.util.Date;

import com.jrj.yqcm.Task;
import com.jrj.yqcm.TaskQueue;
import com.jrj.yqcm.TaskUtil;
import com.jrj.yqcm.utils.HttpComponentUtils;
import com.jrj.yqcm.utils.UrlConstants;

public class TaskOpThread extends Thread {
	private String name;
	TaskQueue taskQueue;
	private String mainCookie;
	private String loginUrl;
	private String host;
	private String taskType;
	private int lrt;
	private int refreshCount = 0;

	public TaskOpThread(String name, TaskQueue taskQueue, String mainCookie,
			String loginUrl, String host, String taskType, int lrt) {
		this.name = name;
		this.taskQueue = taskQueue;
		this.mainCookie = mainCookie;
		this.loginUrl = loginUrl;
		this.host = host;
		this.taskType = taskType;
		this.lrt = lrt;
	}

	public void run() {
		while (true) {
			try {
				HttpComponentUtils.login(loginUrl);
				taskQueue.getTask(taskType);
				System.out.println(name + ",queue:" + taskQueue.size() + ","
						+ taskQueue);
				if (taskQueue.empty()) {
					int leftRefreshTime = TaskUtil.getLeftRefreshTime(
							mainCookie, host);
					System.out.println(name + ":" + "leftRefreshTime:"
							+ leftRefreshTime);
					if (leftRefreshTime > lrt && refreshCount < 6) {
						refreshCount++;
						// try {
						// Thread.sleep(3 * 60 * 1000);
						// } catch (InterruptedException e1) {
						// e1.printStackTrace();
						// }
						HttpComponentUtils.login(loginUrl);
						System.out.println(name + ":" + "refreshTask");
						 TaskUtil.refreshTask(mainCookie, host);
					} else {
						try {
							Thread.sleep(60 * 1000);
						} catch (InterruptedException e1) {
							e1.printStackTrace();
						}
					}
				} else {
					Task t = taskQueue.poll();
					if (t != null) {
						HttpComponentUtils.login(loginUrl);
						TaskUtil.updateScene(t.getSceneId(), mainCookie, host);
						while (t.getLeftMatchId().size() > 0) {
							try {
								String matchId = t.getLeftMatchId().poll();
								String url = (host + UrlConstants.SIGN_COK)
										.replace("$1", matchId);
								HttpComponentUtils.login(loginUrl);
								String content = HttpComponentUtils.get(url,
										mainCookie);
								while (content.indexOf("��ս�ɹ�") == -1) {
									try {
										System.out.println(name + ","
												+ "content:"
												+ formatContent(content));
										Thread.sleep(60 * 1000);
										HttpComponentUtils.login(loginUrl);
										content = HttpComponentUtils.get(url,
												mainCookie);
									} catch (Exception e) {
										e.printStackTrace();
										try {
											Thread.sleep(60 * 1000);
										} catch (InterruptedException e1) {
											e1.printStackTrace();
										}
									}
								}
								System.out.println(name + ","
										+ ",TrainMatchTask," + new Date()
										+ formatContent(content));
							} catch (Exception e) {
								e.printStackTrace();
								try {
									Thread.sleep(60 * 1000);
								} catch (InterruptedException e1) {
									e1.printStackTrace();
								}
							}
						}
					} else {
						try {
							Thread.sleep(60 * 1000);
						} catch (InterruptedException e1) {
							e1.printStackTrace();
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
				try {
					Thread.sleep(60 * 1000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
			}
			HttpComponentUtils.login(loginUrl);
			TaskUtil.getTaskAward(mainCookie, host);
		}
	}

	public String formatContent(String content) {
		int index = -1;
		int begin = -1;
		int end = -1;
		if ((index = content.indexOf("public_d_process")) != -1) {
			begin = index + 18;
		} else if ((index = content.indexOf("public_d_content")) != -1) {
			begin = index + 18;
		}
		end = content.indexOf("</div>", index);
		if (begin != -1 && end != -1) {
			content = content.substring(begin, end);
		}
		return content;
	}

	public int getRefreshCount() {
		return refreshCount;
	}

	public void setRefreshCount(int refreshCount) {
		this.refreshCount = refreshCount;
	}

}
