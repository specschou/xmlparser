package com.jrj.yqcm;

import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import com.jrj.yqcm.Task;
import com.jrj.yqcm.TaskQueue;
import com.jrj.yqcm.TaskUtil;
import com.jrj.yqcm.utils.HttpComponentUtils;
import com.jrj.yqcm.utils.OperateUtil;
import com.jrj.yqcm.utils.UrlConstants;

public class TimeThread extends Thread {
	private String name;
	private String mainCookie;
	private String loginUrl;
	private String host;
	private Map<String, String> params;

	public TimeThread(String name, String mainCookie, String loginUrl,
			String host, Map<String, String> params) {
		this.name = name;
		this.mainCookie = mainCookie;
		this.loginUrl = loginUrl;
		this.host = host;
		this.params = params;
	}

	public void run() {
		while (true) {
			try {
				if (params == null || params.size() == 0) {
					break;
				}
				HttpComponentUtils.login(loginUrl);
				Calendar c = Calendar.getInstance();
				int hour = c.get(Calendar.HOUR_OF_DAY);
				int minute = c.get(Calendar.MINUTE);
				if ("1".equals(params.get("boss"))) {

				}
				if ("1".equals(params.get("stadium"))) {
					if ((hour == 15 && minute >= 0 && minute <= 50)) {
						OperateUtil.enterStadium(mainCookie, host);
					}
				}
				if (params.get("trainIds") != null) {
					if (minute % 5 == 0) {
						OperateUtil.specialTrain(name, params.get("trainIds"),
								mainCookie, host);
					}
				}
				try {
					Thread.sleep(60 * 1000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
			} catch (Exception e) {
				e.printStackTrace();
				try {
					Thread.sleep(60 * 1000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
			}
		}
	}

	public String formatContent(String content) {
		int index = -1;
		int begin = -1;
		int end = -1;
		if ((index = content.indexOf("public_d_process")) != -1) {
			begin = index + 18;
		} else if ((index = content.indexOf("public_d_content")) != -1) {
			begin = index + 18;
		}
		end = content.indexOf("</div>", index);
		if (begin != -1 && end != -1) {
			content = content.substring(begin, end);
		}
		return content;
	}

}
