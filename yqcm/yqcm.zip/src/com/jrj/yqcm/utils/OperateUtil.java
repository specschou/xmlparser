package com.jrj.yqcm.utils;

import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class OperateUtil {
	public static void batchSellPalyers(String[] ids, String user) {
		try {
			Properties props = PropUtil.getProperties(Constants.DIR + user + ".property");
			String cookie = props.getProperty("cookie");
			String host = props.getProperty("host");
			String loginUrl = props.getProperty("loginUrl");
			String name = props.getProperty("name");
			HttpComponentUtils.login(loginUrl);
			for (String id : ids) {
				String url = (host + UrlConstants.SELL_PLAYER)
						.replace("$1", id);
				System.out.println(name + ",url:" + url);
				String content = HttpComponentUtils.get(url, cookie);
				System.out.println(formatContent(content));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String getPlayerList(String user) {
		try {
			Properties props = PropUtil.getProperties(Constants.DIR + user + ".property");
			String cookie = props.getProperty("cookie");
			String host = props.getProperty("host");
			String loginUrl = props.getProperty("loginUrl");
			HttpComponentUtils.login(loginUrl);
			return getPlayerList(user,cookie, host);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}

	public static String getPlayerList(String user,String cookie, String host) {
		StringBuilder sb = new StringBuilder();
		String url = host + UrlConstants.PLAYER_LIST;
		String content = HttpComponentUtils.get(url, cookie);
		// System.out.println("content:" + formatContent(content));
		Pattern p = Pattern.compile("(<span)(.*?)(</span>)");
		Pattern idp = Pattern.compile("(id=\"sp)(.*?)(\">)");
		Matcher m = p.matcher(content);
		sb.append("<form action=\"/batchsell.jsp\">");
		sb.append("<input name=\"user\" type=\"hidden\" value=\"");
		sb.append(user);
		sb.append("\"/>");
		sb.append("<table>");
		while (m.find()) {
			String s = m.group();
			if (s.indexOf("font") != -1) {
				// System.out.println(s);
				Matcher idM = idp.matcher(s);
				if (idM.find()) {
					String id = idM.group(2);
					// System.out.println(id);
					sb.append("<tr>");
					sb.append("<td>");
					sb.append(s);
					sb.append("</td>");
					sb.append("<td>");
					sb.append("<input name=\"ids\" type=\"checkbox\" value=\"");
					sb.append(id);
					sb.append("\"/>");
					sb.append("</td>");
					sb.append("</tr>");
				}
			}
		}
		sb.append("<tr>");
		sb.append("<td>");
		sb.append("</td>");
		sb.append("<td>");
		sb.append("<input name=\"submit\" type=\"submit\" value=\"ȷ��\"/>");
		sb.append("</td>");
		sb.append("</tr>");
		sb.append("</table>");
		sb.append("</form>");
		return sb.toString();
	}

	public static void specialTrain(String name, String trainIds,
			String cookie, String host) {
		if (trainIds != null) {
			String[] a = trainIds.split(",");
			for (String s : a) {
				String url = (host + UrlConstants.MARKET_TRANINER).replace(
						"$1", "7").replace("$2", s);
				String content = HttpComponentUtils.get(url, cookie);
				System.out.println(name + ":" + formatContent(content));
			}
		}
	}

	public static void enterStadium(String cookie, String host) {
		String url = host + UrlConstants.ENTER_STADIUM;
		String content = HttpComponentUtils.get(url, cookie);
		System.out.println("content:" + formatContent(content));
	}

	public static void getTicket(String cookie, String host) {
		String url = (host + UrlConstants.FIN_INS).replace("$1", "4");
		String content = HttpComponentUtils.get(url, cookie);
		System.out.println("content:" + formatContent(content));
	}

	public static void getActiveBag(String cookie, String host) {
		String url = host + UrlConstants.GIFT_BAG;
		String content = HttpComponentUtils.get(url, cookie);
		int start = content.indexOf("OpenOnlineGiftBag");
		if (start != -1) {
			int begin = content.indexOf("(", start);
			int end = content.indexOf(")", begin + 1);
			if (begin != -1 && end != -1) {
				String giftBag = content.substring(begin + 1, end);
				url = (host + UrlConstants.CoinToTool).replace("$1", giftBag);
				content = HttpComponentUtils.get(url, cookie);
				System.out.println("content:" + formatContent(content));
			}
		}
	}

	public static String formatContent(String content) {
		int index = -1;
		int begin = -1;
		int end = -1;
		if ((index = content.indexOf("public_d_process")) != -1) {
			begin = index + 18;
		} else if ((index = content.indexOf("public_d_content")) != -1) {
			begin = index + 18;
		}
		end = content.indexOf("</div>", index);
		if (begin != -1 && end != -1) {
			content = content.substring(begin, end);
		}
		return content;
	}
}
