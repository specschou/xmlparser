package com.jrj.yqcm.utils;

public class Constants {
	public static final String DIR = "D:/workspace/yqcm/webapps/WEB-INF/conf/";
}
