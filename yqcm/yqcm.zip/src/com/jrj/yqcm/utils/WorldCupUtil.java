package com.jrj.yqcm.utils;

public class WorldCupUtil {
	public static void enterWorldCup(String cookie, String host) {
		String url = host + UrlConstants.ENTER_WORLDCUP;
		String content = HttpComponentUtils.get(url, cookie);
		System.out.println("content:" + OperateUtil.formatContent(content));
	}

	public static void createRoom(String cookie, String host) {
		String url = host + UrlConstants.CREATE_ROOM;
		String content = HttpComponentUtils.get(url, cookie);
		System.out.println("content:" + OperateUtil.formatContent(content));
	}

	public static String getRoomId(String captain, String cookie, String host) {
		String roomId = null;
		String url = host + UrlConstants.SHOW_TEAM;
		String content = HttpComponentUtils.get(url, cookie);
		System.out.println("content:" + content);
		return roomId;
	}

	public static void enterRoom(String roomId, String cookie, String host) {
		String url = (host + UrlConstants.ENTER_ROOM).replace("$1", roomId);
		String content = HttpComponentUtils.get(url, cookie);
		System.out.println("content:" + OperateUtil.formatContent(content));
	}
}
